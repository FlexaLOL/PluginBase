Olá, se você está lendo isso, quer dizer que você está lendo :)

Informações:
 * Plugin base para iniciantes, por FlexaLOL
 * Versão 1.8.8 (Spigot)
 * Feito com IntelliJIDEA

Licensa:
 * Você pode fazer o que quiser com o plugin, usar como base para
plugins seus, aprender como se faz o básico por aqui ou outros.
   * Se você for ensinar alguém ou melhorar o plugin, fale que o dono é o FlexaLOL e você na parte de Authors e de os créditos devidos
    
2021 FlexaLOL (c)